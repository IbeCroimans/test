package jens.ibe.lars.idleminer.model;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ibe06
 */

public class GameModel {
    private double balance;
    private double incomePerSecond;

    public GameModel() {
        this.balance = 0;
        this.incomePerSecond = 1; // Beginwaarde van inkomen per seconde
    }

    public double getBalance() {
        return balance;
    }

    public void increaseBalance(double amount) {
        this.balance += amount;
    }

    public double getIncomePerSecond() {
        return incomePerSecond;
    }

    public void upgradeIncome() {
        this.incomePerSecond *= 1.5; // Verhoog het inkomen per seconde met 50%
    }

    public void generateIncome() {
        this.balance += incomePerSecond;
    }
}