/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package jens.lars.ibe.idleminer.controller;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;
import jens.ibe.lars.idleminer.model.GameModel;

public class App extends Application {
    private GameModel gameModel;
    private Label balanceLabel;
    private static App instance;

    public App() {
        instance = this;
    }

    public static App getInstance() {
        return instance;
    }

    @Override
    public void start(Stage primaryStage) {
        gameModel = new GameModel();

        // Maak GUI-componenten aan
        balanceLabel = new Label("Balance: $0.00");
        balanceLabel.setStyle("-fx-font-size: 20px;");

        Button earnIncomeButton = new Button("Earn Income");
        earnIncomeButton.setOnAction(e -> onEarnIncome());

        Button upgradeIncomeButton = new Button("Upgrade Income");
        upgradeIncomeButton.setOnAction(e -> onUpgradeIncome());

        VBox root = new VBox(10, balanceLabel, earnIncomeButton, upgradeIncomeButton);
        root.setAlignment(Pos.CENTER);

        // Stel een timeline in om passief inkomen te genereren
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            gameModel.generateIncome();
            updateView();
        }));
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();

        // Maak en toon het venster
        Scene scene = new Scene(root, 300, 200);
        primaryStage.setTitle("Idle Miner Tycoon");
        primaryStage.setScene(scene);
        primaryStage.show();

        updateView();
    }

    private void onEarnIncome() {
        gameModel.increaseBalance(10); // Voeg $10 toe bij klikken
        updateView();
    }

    private void onUpgradeIncome() {
        gameModel.upgradeIncome();
        updateView();
    }

    private void updateView() {
        balanceLabel.setText(String.format("Balance: $%.2f", gameModel.getBalance()));
    }

    public static void main(String[] args) {
        launch();
    }
}
