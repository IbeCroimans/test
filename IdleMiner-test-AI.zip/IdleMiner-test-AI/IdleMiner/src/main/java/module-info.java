module jens.lars.ibe.idleminer {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens jens.lars.ibe.idleminer to javafx.fxml;
    exports jens.lars.ibe.idleminer;
}
